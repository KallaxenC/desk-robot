"""
The conversational brain. Same OpenRouter-via-openai-SDK pattern as
your original script, minus the LED/action JSON envelope -- since
there's no hardware action to route right now, the model just returns
plain text to speak. If you bring back robot actions later (motors,
lights, whatever), this is the file to reintroduce a JSON schema in --
the "action" field pattern from your original script slots back in
here cleanly.
"""

from openai import OpenAI

import config

_client = OpenAI(
    base_url=config.OPENROUTER_BASE_URL,
    api_key=config.OPENROUTER_API_KEY,
)

SYSTEM_PROMPT = (
    "You are a friendly voice assistant built into a small desk robot. "
    "Keep replies short and conversational -- a sentence or two, like "
    "you're actually speaking out loud, not writing. No markdown, no "
    "lists, no emoji."
)

# Rolling conversation history, so the assistant has short-term memory
# across turns within a session (cleared on restart).
_history = []


def get_response(user_text: str) -> str:
    """Send the user's transcribed speech to the LLM, return reply text to speak."""
    _history.append({"role": "user", "content": user_text})
    _trim_history()

    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + _history

    completion = _client.chat.completions.create(
        model=config.CHAT_MODEL,
        messages=messages,
    )
    reply_text = completion.choices[0].message.content.strip()

    _history.append({"role": "assistant", "content": reply_text})
    _trim_history()

    return reply_text


def _trim_history():
    max_messages = config.MAX_HISTORY_TURNS * 2  # user + assistant per turn
    if len(_history) > max_messages:
        del _history[: len(_history) - max_messages]
