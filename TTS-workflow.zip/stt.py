"""
Speech-to-text via OpenRouter's dedicated transcription endpoint.
"""

import requests

import config


def transcribe(wav_path: str) -> str:
    """Send a recorded WAV file to OpenRouter and return the transcript text."""
    url = f"{config.OPENROUTER_BASE_URL}/audio/transcriptions"
    headers = {"Authorization": f"Bearer {config.OPENROUTER_API_KEY}"}

    with open(wav_path, "rb") as f:
        files = {"file": (wav_path, f, "audio/wav")}
        data = {"model": config.STT_MODEL}
        response = requests.post(url, headers=headers, files=files, data=data, timeout=30)

    response.raise_for_status()
    result = response.json()

    # Response shape mirrors OpenAI's transcription endpoint: {"text": "..."}
    return result.get("text", "").strip()
