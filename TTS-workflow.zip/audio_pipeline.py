"""
Owns the microphone. This is deliberately the ONLY thing in the whole
project that opens the audio input device, because two things trying
to grab the same ALSA device at once is a classic source of "device
busy" errors on the Pi.

Design: one continuous sounddevice InputStream feeds small (80ms)
chunks into a queue. A worker thread drains that queue and runs one of
two behaviours depending on state:

  WAKE   - feed each chunk into openWakeWord, waiting for the phrase
  RECORD - buffer chunks, using webrtcvad to detect when the person
           has stopped talking, then hand the finished clip off

This means wake-word listening and command recording share a single
mic stream instead of each trying to open their own.
"""

import queue
import struct
import threading
import time
import wave
from pathlib import Path

import numpy as np
import sounddevice as sd
import webrtcvad
from openwakeword.model import Model as WakeWordModel

import config


class AudioPipeline:
    def __init__(self, on_utterance):
        """
        on_utterance: callback called with a path to a recorded WAV
        file once a full command has been captured (after wake word
        + speech + trailing silence). Called from the worker thread,
        so whatever it does will block further wake-word listening
        until it returns -- which is what you want, since you don't
        want the assistant hearing itself or double-triggering while
        it's still handling the last thing you said.
        """
        self._on_utterance = on_utterance
        self._audio_q = queue.Queue()
        self._running = False
        self._worker_thread = None

        self._state = "wake"  # "wake" or "record"
        self._record_buffer = bytearray()
        self._silence_ms = 0
        self._record_start_time = None

        self._vad = webrtcvad.Vad(config.VAD_AGGRESSIVENESS)

        # openWakeWord model. If WAKE_WORD_MODEL_PATH is a bare name
        # like "hey_jarvis" it'll resolve one of the bundled pretrained
        # models; if it's a filesystem path to a .tflite/.onnx it'll
        # load your custom-trained model instead.
        self._oww_model = WakeWordModel(
            wakeword_models=[config.WAKE_WORD_MODEL_PATH],
        )
        # openWakeWord model keys are usually derived from the filename
        # / model name -- this grabs whichever one it registered so we
        # don't have to hardcode the exact key string.
        self._wake_model_key = list(self._oww_model.models.keys())[0]

    # ------------------------------------------------------------------
    # Public control
    # ------------------------------------------------------------------

    def start(self):
        self._running = True
        self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker_thread.start()

        self._stream = sd.InputStream(
            samplerate=config.SAMPLE_RATE,
            channels=config.CHANNELS,
            dtype="int16",
            blocksize=config.CHUNK_SAMPLES,
            device=config.INPUT_DEVICE,
            callback=self._sd_callback,
        )
        self._stream.start()

    def stop(self):
        self._running = False
        if hasattr(self, "_stream"):
            self._stream.stop()
            self._stream.close()
        if self._worker_thread:
            self._worker_thread.join(timeout=2.0)

    def run_forever(self):
        """Convenience blocking call for a simple main.py loop."""
        self.start()
        try:
            while self._running:
                time.sleep(0.25)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()

    # ------------------------------------------------------------------
    # Audio capture callback -- keep this FAST, no blocking work here
    # ------------------------------------------------------------------

    def _sd_callback(self, indata, frames, time_info, status):
        if status:
            # Overflows/underflows show up here -- worth printing during
            # development, safe to ignore occasional ones in practice.
            print(f"[audio] stream status: {status}")
        # indata is a numpy int16 array; copy raw bytes into the queue
        self._audio_q.put(bytes(indata))

    # ------------------------------------------------------------------
    # Worker: state machine over the audio chunks
    # ------------------------------------------------------------------

    def _worker_loop(self):
        while self._running:
            try:
                chunk = self._audio_q.get(timeout=0.5)
            except queue.Empty:
                continue

            if self._state == "wake":
                self._handle_wake_chunk(chunk)
            elif self._state == "record":
                self._handle_record_chunk(chunk)

    def _handle_wake_chunk(self, chunk):
        audio_np = np.frombuffer(chunk, dtype=np.int16)
        prediction = self._oww_model.predict(audio_np)
        score = prediction.get(self._wake_model_key, 0.0)

        if score >= config.WAKE_WORD_THRESHOLD:
            print(f"[wake] triggered (score={score:.2f})")
            self._oww_model.reset()
            self._enter_record_state()

    def _enter_record_state(self):
        self._state = "record"
        self._record_buffer = bytearray()
        self._silence_ms = 0
        self._record_start_time = time.time()

    def _handle_record_chunk(self, chunk):
        self._record_buffer.extend(chunk)

        # Split this 80ms chunk into 8 x 10ms frames for webrtcvad,
        # which requires exactly 10/20/30ms frames at these sample rates.
        frame_bytes = int(config.SAMPLE_RATE * 0.01) * config.SAMPLE_WIDTH  # 10ms
        any_speech = False
        for i in range(0, len(chunk), frame_bytes):
            frame = chunk[i : i + frame_bytes]
            if len(frame) < frame_bytes:
                continue
            if self._vad.is_speech(frame, config.SAMPLE_RATE):
                any_speech = True

        if any_speech:
            self._silence_ms = 0
        else:
            self._silence_ms += 80  # this chunk's duration

        elapsed = time.time() - self._record_start_time
        hit_silence_limit = self._silence_ms >= config.VAD_SILENCE_MS_TO_STOP
        hit_max_duration = elapsed >= config.VAD_MAX_UTTERANCE_S

        if hit_silence_limit or hit_max_duration:
            self._finish_recording()

    def _finish_recording(self):
        wav_path = self._save_wav(bytes(self._record_buffer))
        self._state = "wake"
        self._record_buffer = bytearray()

        # Run the callback synchronously on this thread. This is
        # intentional: while we're transcribing / thinking / speaking,
        # we do NOT want to be scoring wake-word chunks (that would let
        # the assistant's own TTS output re-trigger itself, or start
        # buffering a new command mid-reply).
        try:
            self._on_utterance(wav_path)
        except Exception as exc:
            print(f"[audio] error handling utterance: {exc}")

    @staticmethod
    def _save_wav(pcm_bytes: bytes) -> str:
        out_dir = Path("/tmp/desk_robot_audio")
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"utterance_{int(time.time() * 1000)}.wav"

        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(config.CHANNELS)
            wf.setsampwidth(config.SAMPLE_WIDTH)
            wf.setframerate(config.SAMPLE_RATE)
            wf.writeframes(pcm_bytes)

        return str(path)
