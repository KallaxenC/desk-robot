"""
Audio playback. Deliberately shells out to `paplay` rather than using
a Python audio library -- you confirmed on-device that `paplay` is
what actually reaches the Bluetooth speaker via PipeWire/WirePlumber,
while plain ALSA (which most Python audio libraries default to) does
not. No point re-fighting that battle from inside Python.
"""

import subprocess


def play_and_wait(wav_path: str) -> None:
    """Blocks until playback finishes -- call this while face.talk_start()
    is active, then call face.talk_stop() right after it returns."""
    subprocess.run(["paplay", wav_path], check=True)
