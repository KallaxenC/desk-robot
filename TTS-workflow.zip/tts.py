"""
Text-to-speech via OpenRouter's dedicated speech endpoint.
Returns a path to a saved audio file, ready to hand to player.py.
"""

import time
from pathlib import Path

import requests

import config


def synthesize(text: str) -> str:
    """Send text to OpenRouter TTS and save the resulting audio to a file."""
    url = f"{config.OPENROUTER_BASE_URL}/audio/speech"
    headers = {
        "Authorization": f"Bearer {config.OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": config.TTS_MODEL,
        "input": text,
        "voice": config.TTS_VOICE,
        "response_format": "wav",
    }

    response = requests.post(url, headers=headers, json=payload, timeout=30)
    response.raise_for_status()

    out_dir = Path("/tmp/desk_robot_audio")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"reply_{int(time.time() * 1000)}.wav"
    out_path.write_bytes(response.content)

    return str(out_path)
