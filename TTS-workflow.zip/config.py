"""
Central config for the voice assistant pipeline.

Everything that's likely to need tweaking lives here, so you're not
hunting through multiple files to change a model name or a threshold.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ---- OpenRouter auth ----
OPENROUTER_API_KEY = os.getenv("DESK_ROBOT_API_KEY")
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

if not OPENROUTER_API_KEY:
    raise RuntimeError(
        "DESK_ROBOT_API_KEY not set. Add it to a .env file "
        "(see .env.example) in this directory."
    )

# ---- Model selection ----
# NOTE: OpenRouter added dedicated audio endpoints recently, and model
# slugs on new endpoints do shift as providers add/rename entries.
# Double check these three against https://openrouter.ai/models
# (filter by "audio" / "speech" / "transcription" modality) before your
# first real run — if a request 404s or complains about the model
# string, that's almost always the fix.
CHAT_MODEL = "openai/gpt-4o-mini"
STT_MODEL = "openai/gpt-4o-mini-transcribe"
TTS_MODEL = "openai/gpt-4o-mini-tts"
TTS_VOICE = "alloy"

# ---- Audio format ----
# 16kHz mono is the sweet spot for speech: small enough to keep STT
# uploads quick and cheap, plenty for speech intelligibility, and it's
# a size webrtcvad and openWakeWord both expect natively.
SAMPLE_RATE = 16000
CHANNELS = 1
SAMPLE_WIDTH = 2  # bytes per sample (16-bit PCM)

# Audio is captured in fixed-size chunks. 1280 samples @ 16kHz = 80ms,
# which is what openWakeWord's predict() expects per call, and it
# divides evenly into 8 x 10ms frames for webrtcvad.
CHUNK_SAMPLES = 1280

# ---- Input device ----
# Set this to the ALSA device your USB mic actually enumerates as.
# You confirmed `arecord -D plughw:2,0 ...` works — sounddevice wants
# just the ALSA device string, no "plughw:" prefix logic needed since
# we ask PortAudio for it directly. If your mic ever re-enumerates to
# a different card number after a reboot, update this (or see the
# note in audio_pipeline.py about matching by name instead).
INPUT_DEVICE = "plughw:2,0"

# ---- Wake word ----
# Path to a wake-word model file (.tflite or .onnx) for openWakeWord.
# openWakeWord ships several pretrained words (e.g. "hey_jarvis") you
# can test with immediately. A custom "hey computer" model needs to be
# trained separately via openWakeWord's training notebook/pipeline
# (it generates synthetic training audio for your chosen phrase) —
# that's not something to generate here, it's a one-time offline step
# on your end. Point this at whichever .tflite you end up with.
WAKE_WORD_MODEL_PATH = os.getenv("WAKE_WORD_MODEL_PATH", "hey_jarvis")
WAKE_WORD_THRESHOLD = 0.5  # confidence 0-1 to trigger; tune after testing

# ---- Voice activity detection (end-of-utterance) ----
VAD_AGGRESSIVENESS = 2  # webrtcvad: 0 (least aggressive) - 3 (most aggressive)
VAD_SILENCE_MS_TO_STOP = 900  # trailing silence before we consider speech done
VAD_MAX_UTTERANCE_S = 12  # hard cap so a stuck stream can't record forever

# ---- Conversation ----
MAX_HISTORY_TURNS = 6  # how many past exchanges to keep in context
