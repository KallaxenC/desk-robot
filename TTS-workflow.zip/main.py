"""
Entrypoint. Wires together:

  RobotFace         -- your existing display/animation class
  AudioPipeline     -- wake word + VAD recording (owns the mic)
  stt.transcribe     -- OpenRouter speech-to-text
  brain.get_response -- OpenRouter LLM reply
  tts.synthesize      -- OpenRouter text-to-speech
  player.play_and_wait -- blocking playback via paplay

Flow per interaction:
  wake word heard -> record until silence -> transcribe -> ask LLM
  -> synthesize reply -> face.talk_start() -> play audio -> face.talk_stop()
"""

from audio_pipeline import AudioPipeline
from brain import get_response
from player import play_and_wait
from stt import transcribe
from tts import synthesize

# This assumes your existing display script is saved as
# tft_screen_control.py in the same directory (the file you shared).
from tft_screen_control import RobotFace


def make_utterance_handler(face: RobotFace):
    def handle_utterance(wav_path: str):
        user_text = transcribe(wav_path)
        print(f"[you]  {user_text}")

        if not user_text.strip():
            # Empty transcript (e.g. wake word triggered on noise) --
            # just go back to listening rather than sending nothing to
            # the LLM and getting a confused reply.
            return

        reply_text = get_response(user_text)
        print(f"[bot]  {reply_text}")

        audio_path = synthesize(reply_text)

        face.talk_start()
        try:
            play_and_wait(audio_path)
        finally:
            face.talk_stop()

    return handle_utterance


def main():
    face = RobotFace()
    face.start()

    pipeline = AudioPipeline(on_utterance=make_utterance_handler(face))

    print("Listening for wake word. Ctrl+C to quit.")
    try:
        pipeline.run_forever()
    finally:
        face.stop()


if __name__ == "__main__":
    main()
