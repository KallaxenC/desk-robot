# Desk robot voice pipeline

## Setup

```bash
cp .env.example .env
# edit .env with your real DESK_ROBOT_API_KEY

pip install -r requirements.txt
```

Put `tft_screen_control.py` (your existing RobotFace class) in this
same directory -- `main.py` imports `RobotFace` from it directly.

## Before your first real run

1. **Verify the model slugs in `config.py`.** `CHAT_MODEL` should
   already work fine (same one your original script used). `STT_MODEL`
   and `TTS_MODEL` are on OpenRouter's newer dedicated audio endpoints
   -- check https://openrouter.ai/models (filter by transcription /
   speech modality) and confirm the exact slug strings match what's
   currently listed, since these are newer additions and naming can
   shift.

2. **Test with the pretrained "hey_jarvis" wake word first.** It's
   bundled with openWakeWord, so you can confirm the whole pipeline
   (mic -> wake detection -> record -> STT -> LLM -> TTS -> speaker)
   works end to end before worrying about a custom phrase.

3. **Train your own "hey computer" model separately**, using
   openWakeWord's training pipeline (it synthesizes training audio for
   your chosen phrase -- this happens outside this codebase, as a
   one-off step). Once you have a `.tflite` file, point
   `WAKE_WORD_MODEL_PATH` in `.env` at it.

## Recommended test order

1. `python3 -c "from tft_screen_control import RobotFace; f = RobotFace(); f.start(); import time; time.sleep(3); f.talk_for(3); time.sleep(4); f.stop()"`
   -- confirms the face still runs standalone.
2. `python3 -c "from stt import transcribe; print(transcribe('test.wav'))"`
   using the `test.wav` from your earlier `arecord` test -- confirms
   OpenRouter STT works before any mic/wake-word code is involved.
3. `python3 -c "from tts import synthesize; from player import play_and_wait; p = synthesize('Hello, this is a test.'); play_and_wait(p)"`
   -- confirms OpenRouter TTS + `paplay` playback works in isolation.
4. `python3 -c "from brain import get_response; print(get_response('Hello there'))"`
   -- confirms the LLM leg works on its own.
5. Only once 1-4 all work individually: `python3 main.py` for the
   full loop.

Testing each leg standalone like this means if something breaks in
the full pipeline, you already know it's not the mic, not the speaker,
not the API key, and not the model -- it's specifically the
wake-word/VAD glue in `audio_pipeline.py`, which narrows debugging a
lot.

## Known things to tune once it's running

- `WAKE_WORD_THRESHOLD` in `config.py` -- raise it if it triggers on
  background noise/TV, lower it if it's not catching your voice.
- `VAD_SILENCE_MS_TO_STOP` -- how long a pause before it decides
  you're done talking. Shorter feels snappier but risks cutting off
  slow speakers; longer feels safer but adds latency before it responds.
- `VAD_AGGRESSIVENESS` -- how strictly webrtcvad classifies frames as
  speech vs. not. Higher filters out more background noise but can
  also clip quiet speech.
